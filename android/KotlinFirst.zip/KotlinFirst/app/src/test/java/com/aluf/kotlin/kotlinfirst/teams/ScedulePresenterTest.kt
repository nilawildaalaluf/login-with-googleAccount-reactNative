package com.aluf.kotlin.kotlinfirst.teams


import com.aluf.kotlin.kotlinfirst.TestContextProvider
import com.aluf.kotlin.kotlinfirst.config.ApiRespository
import com.aluf.kotlin.kotlinfirst.config.TheSportDBApi
import com.aluf.kotlin.kotlinfirst.config.repository.LocalRepositoryApi
import com.aluf.kotlin.kotlinfirst.list.schedule.ScedulePresenter
import com.aluf.kotlin.kotlinfirst.list.schedule.SceduleView
import com.aluf.kotlin.kotlinfirst.model.event.Event
import com.aluf.kotlin.kotlinfirst.model.event.FootballMatch
import com.google.gson.Gson
import org.junit.Before
import org.junit.Test
import org.mockito.Mock
import org.mockito.Mockito
import org.mockito.MockitoAnnotations

class ScedulePresenterTest {
    @Mock
    private
    lateinit var view: SceduleView

    @Mock
    private
    lateinit var gson: Gson

    @Mock
    private
    lateinit var apiRepository: ApiRespository
    @Mock
    private
    lateinit var localRepositoryApi: LocalRepositoryApi

    private lateinit var presenter: ScedulePresenter

    @Before
    fun setUp() {
        MockitoAnnotations.initMocks(this)
        presenter = ScedulePresenter(view, apiRepository, gson,localRepositoryApi,TestContextProvider())
    }

    @Test
    fun testGetScedule() {
        val events: MutableList<Event> = mutableListOf()
        val response = FootballMatch(events)
        val leagueId = "4328"

        Mockito.`when`(
                gson.fromJson(apiRepository.doRequest(TheSportDBApi.getEventLast(leagueId)), FootballMatch::class.java)

        ).thenReturn(response)

        presenter.getEventLast(leagueId)

        Mockito.verify(view).showLoading()
        Mockito.verify(view).showEventLast(events)
        Mockito.verify(view).hideLoading()
    }

}