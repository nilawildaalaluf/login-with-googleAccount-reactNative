package com.aluf.kotlin.kotlinfirst

import com.aluf.kotlin.kotlinfirst.detail.CoroutineContextProvider
import kotlinx.coroutines.experimental.Unconfined
import kotlin.coroutines.experimental.CoroutineContext

class TestContextProvider : CoroutineContextProvider() {
    override val main: CoroutineContext = Unconfined
}