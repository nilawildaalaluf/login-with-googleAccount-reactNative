package com.aluf.kotlin.kotlinfirst.home

import android.support.test.espresso.Espresso.onView
import android.support.test.espresso.Espresso.pressBack
import android.support.test.espresso.action.ViewActions.click
import android.support.test.espresso.assertion.ViewAssertions.matches
import android.support.test.espresso.contrib.RecyclerViewActions
import android.support.test.espresso.matcher.ViewMatchers.*
import android.support.test.rule.ActivityTestRule
import android.support.test.runner.AndroidJUnit4
import android.support.v7.widget.RecyclerView
import com.aluf.kotlin.kotlinfirst.MainActivity
import com.aluf.kotlin.kotlinfirst.R.id.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith


@RunWith(AndroidJUnit4::class)
class HomeActivityTest {
    @Rule
    @JvmField var activityRule = ActivityTestRule(MainActivity::class.java)

    @Test
    fun testRecyclerViewBehaviour() {
        delay()
        onView(withId(list_team))
            .check(matches(isDisplayed()))
        delay()
        onView(withId(list_team)).perform(RecyclerViewActions.scrollToPosition<RecyclerView.ViewHolder>(10))
        delay()
        onView(withId(list_team)).perform(
            RecyclerViewActions.actionOnItemAtPosition<RecyclerView.ViewHolder>(10, click()))
    }

    @Test
    fun testAppBehaviour() {

        onView(withId(spinner))
            .check(matches(isDisplayed()))
        delay()

        onView(withId(spinner)).perform(click())
        onView(withText("Spanish La Liga")).perform(click())
        delay()

        onView(withText("Barcelona"))
            .check(matches(isDisplayed()))
        onView(withText("Barcelona")).perform(click())
        delay()

        onView(withId(add_to_favorite))
            .check(matches(isDisplayed()))
        onView(withId(add_to_favorite)).perform(click())
        onView(withText("Added to favorite"))
            .check(matches(isDisplayed()))
        delay()

        pressBack()
        delay()

        onView(withId(bottom_navigation))
            .check(matches(isDisplayed()))

        onView(withId(match)).perform(click())
        delay()
        onView(withId(last_match)).perform(click())
        delay()

        onView(withText("Chelsea"))
            .check(matches(isDisplayed()))
        onView(withText("Chelsea")).perform(click())
        delay()

        onView(withId(add_to_favorite))
            .check(matches(isDisplayed()))
        onView(withId(add_to_favorite)).perform(click())
        delay()
        pressBack()
        delay()

        onView(withId(upcoming_match)).perform(click())
        delay()
        onView(withId(favorites)).perform(click())
        delay()
        onView(withId(favorite)).perform(click())
        delay()
    }

    private fun delay(){
        try {
            Thread.sleep(4000)
        }catch (e: InterruptedException){
            e.printStackTrace()
        }
    }


}

