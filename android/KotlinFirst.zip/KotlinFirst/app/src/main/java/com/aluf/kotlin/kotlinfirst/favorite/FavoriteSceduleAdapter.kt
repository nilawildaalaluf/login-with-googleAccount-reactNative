package com.aluf.kotlin.kotlinfirst.favorite

import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import com.aluf.kotlin.kotlinfirst.OnItemClickListener
import com.aluf.kotlin.kotlinfirst.R
import com.aluf.kotlin.kotlinfirst.model.event.Event
import com.aluf.kotlin.kotlinfirst.model.favorite.FavoriteScedule
import com.aluf.kotlin.kotlinfirst.utils.DateFormatter
import org.jetbrains.anko.sdk15.coroutines.onClick

class FavoriteSceduleAdapter (private val favoritesScedule: List<FavoriteScedule>, private val listener: (FavoriteScedule) -> Unit) :
    RecyclerView.Adapter<FavoriteSceduleHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int)=
        FavoriteSceduleHolder(LayoutInflater.from(parent.context).inflate(R.layout.list_scedule, parent, false))


    override fun getItemCount(): Int {
        return favoritesScedule.size
    }

    override fun onBindViewHolder(holder: FavoriteSceduleHolder, position: Int) {
        holder.bindItem(favoritesScedule[position], listener)

    }
}

class FavoriteSceduleHolder(view: View) : RecyclerView.ViewHolder(view) {
    private val dateSoccer = view.findViewById<TextView>(R.id.date_soccer)
    private val nameHomeSoccer = view.findViewById<TextView>(R.id.home_soccer)
    private val scoreHomeSoccer = view.findViewById<TextView>(R.id.score_home_soccer)
    private val nameAwaySoccer = view.findViewById<TextView>(R.id.away_soccer)
    private val scoreAwaySoccer = view.findViewById<TextView>(R.id.score_away_soccer)

    fun bindItem(favoritesScedule: FavoriteScedule, listener: (FavoriteScedule) -> Unit) {
        nameHomeSoccer.text = favoritesScedule.idHomeTeamName
        nameAwaySoccer.text = favoritesScedule.idAwayTeamName
        scoreHomeSoccer.text = favoritesScedule.scrHomeTeam
        scoreAwaySoccer.text = favoritesScedule.scrAwayTeam
//        dateSoccer.text = favoritesScedule.dateSchedule

        try {
            val eventDate = DateFormatter.formatToDate(favoritesScedule.dateSchedule, "dd/MM/yy")
            dateSoccer.text = DateFormatter.formatToString(eventDate, "EEEE, dd MMMM yyyy")
//            timeSoccer.text = DateFormatter.formatToString(eventDate, "HH:ss")
        } catch (e: Exception) {
        }

        itemView.onClick {
            listener(favoritesScedule)
        }

    }

}
