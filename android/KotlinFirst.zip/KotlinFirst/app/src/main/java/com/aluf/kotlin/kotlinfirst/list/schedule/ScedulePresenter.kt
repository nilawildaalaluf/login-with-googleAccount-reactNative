package com.aluf.kotlin.kotlinfirst.list.schedule

import com.aluf.kotlin.kotlinfirst.config.ApiRespository
import com.aluf.kotlin.kotlinfirst.config.TheSportDBApi
import com.aluf.kotlin.kotlinfirst.config.repository.LocalRepositoryApi
import com.aluf.kotlin.kotlinfirst.detail.CoroutineContextProvider
import com.aluf.kotlin.kotlinfirst.model.event.FootballMatch
import com.aluf.kotlin.kotlinfirst.model.favorite.FavoriteScedule
import com.google.gson.Gson
import kotlinx.coroutines.experimental.async
import org.jetbrains.anko.coroutines.experimental.bg

class ScedulePresenter(private val view: SceduleView,
                       private val apiRepository: ApiRespository,
                       private val gson: Gson,
                       val localRepositoryApi: LocalRepositoryApi,
                       private val context: CoroutineContextProvider = CoroutineContextProvider()
) {
    fun getEventLast(leagueId: String?) {
        view.showLoading()

        async(context.main) {
            //Proses request di background
            val data = bg {
                gson.fromJson(apiRepository.doRequest(TheSportDBApi.getEventLast(leagueId)), FootballMatch::class.java)
            }

            view.showEventLast(data.await().events)
            view.hideLoading()
        }
    }
    fun getNextMatch(leagueId: String?) {
        view.showLoading()
        async(context.main){
            val data = bg{gson.fromJson(apiRepository
                .doRequest(TheSportDBApi.getUpcomingMatch(leagueId)),
                FootballMatch::class.java
            )}

                view.hideLoading()
                view.showNextMatch(data.await().events)

        }
    }

    fun getFavoriteMatch() {
        view.showLoading()
        val favList = localRepositoryApi.getMatchFromDb()
        var eventList: MutableList<FavoriteScedule> = mutableListOf()
        eventList.addAll(favList)
        view.hideLoading()
        view.showFavoriteMatch(eventList)
    }

}
