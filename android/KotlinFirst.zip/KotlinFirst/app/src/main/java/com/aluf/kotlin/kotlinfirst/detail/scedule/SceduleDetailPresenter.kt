package com.aluf.kotlin.kotlinfirst.detail.scedule

import com.aluf.kotlin.kotlinfirst.config.ApiRespository
import com.aluf.kotlin.kotlinfirst.config.TheSportDBApi
import com.aluf.kotlin.kotlinfirst.config.repository.LocalRepositoryApi
import com.aluf.kotlin.kotlinfirst.model.TeamResponse
import com.aluf.kotlin.kotlinfirst.model.event.Event
import com.aluf.kotlin.kotlinfirst.model.event.FootballMatch
import com.aluf.kotlin.kotlinfirst.model.favorite.FavoriteScedule
import com.google.gson.Gson
import org.jetbrains.anko.doAsync
import org.jetbrains.anko.uiThread

class SceduleDetailPresenter(private val view: SceduleDetailView.View,
                             private val apiRepository: ApiRespository,
                             private val gson: Gson,
                             private val localRepositoryApi: LocalRepositoryApi
) {
    fun showDataTeam(event: Event?){
        view.showDataTeam(event)
    }
    fun getTeamsBadgeHome(teamId: String?) {
        //view.showLoading()
        doAsync {
            val data = gson.fromJson(apiRepository
                .doRequest(TheSportDBApi.getTeamDetail(teamId)),
                TeamResponse::class.java
            )

            uiThread {
                //                view.hideLoading()
                view.displayTeamBadgeHome(data.teams[0])
            }
        }
    }
    fun getTeamsBadgeAway(teamId: String?) {
        //view.showLoading()
        doAsync {
            val data = gson.fromJson(apiRepository
                .doRequest(TheSportDBApi.getTeamDetail(teamId)),
                TeamResponse::class.java
            )

            uiThread {
                //                view.hideLoading()
                view.displayTeamBadgeAway(data.teams[0])
            }
        }
    }
    fun showDataFavoriteTeam(favorite: FavoriteScedule?){
        if(favorite != null) {
            doAsync {
                val data = gson.fromJson(apiRepository
                    .doRequest(TheSportDBApi.getEventById(favorite.idEvent)),
                    FootballMatch::class.java
                )
                val event = data.events[0]
                uiThread {
                    //                view.hideLoading()
                    view.showDataTeam(event)
                }
            }
        }
    }

    fun insertMatch(eventId: String, homeId: String, awayId: String, homeScore : String? , awayScore : String?, homeName: String, awayName: String, dateSchedule:String, timeScedule:String?) {
        localRepositoryApi.insertData(eventId, homeId, awayId, homeScore, awayScore, homeName, awayName, dateSchedule, timeScedule)
    }
     fun deleteMatch(id: String) {
        localRepositoryApi.deleteData(id)
    }
   fun checkMatch(id: String) {
        view.setFavoriteState(localRepositoryApi.checkFavorite(id))
    }

}