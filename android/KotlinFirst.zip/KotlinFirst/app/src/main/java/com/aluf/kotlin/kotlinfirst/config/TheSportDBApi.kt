package com.aluf.kotlin.kotlinfirst.config

import android.net.Uri
import com.aluf.kotlin.kotlinfirst.BuildConfig
import java.net.URLEncoder

object TheSportDBApi {


    fun getTeams(league: String?): String {
        return BuildConfig.BASE_URL + "api/v1/json/${BuildConfig.API_KEY}" + "/search_all_teams.php?l=" + league
    }

    fun getTeamDetail(teamId: String?): String {
        return BuildConfig.BASE_URL +
                "api/v1/json/${BuildConfig.API_KEY}/lookupteam.php?id=" + teamId
    }

    fun getAllEvent(): String  {
        return BuildConfig.BASE_URL +
                "api/v1/json/${BuildConfig.API_KEY}/search_all_leagues.php?s=Soccer"
    }

    fun getEventLast(leagueId: String?): String {
        return BuildConfig.BASE_URL +
                "api/v1/json/${BuildConfig.API_KEY}/eventspastleague.php?id=" + leagueId
    }

    fun getUpcomingMatch(leagueId: String?): String{
        return BuildConfig.BASE_URL +
                "api/v1/json/${BuildConfig.API_KEY}/eventsnextleague.php?id=" + leagueId
    }
    fun getEventById(eventId: String?): String{
        return BuildConfig.BASE_URL +
                "api/v1/json/${BuildConfig.API_KEY}/lookupevent.php?id=" + eventId
    }


//
//    @GET("eventspastleague.php")
//    fun getLastmatch(@Query("id") id:String) : Flowable<FootballMatch>
//
//    @GET("eventsnextleague.php")
//    fun getUpcomingMatch(@Query("id") id:String) : Flowable<FootballMatch>
//
//    @GET("searchevents.php?e=")
//    fun searchMatches(@Query("e") query: String?) : Flowable<SearchedMatches>
//
//    @GET("lookupteam.php")
//    fun getTeams(@Query("id") id:String) : Flowable<Team>
//
//    @GET("searchteams.php")
//    fun getTeamBySearch(@Query("t") query: String) : Flowable<Team>
//
//    @GET("lookup_all_teams.php")
//    fun getAllTeam(@Query("id") id:String) : Flowable<Team>
}