package com.aluf.kotlin.kotlinfirst.list.league

import android.support.v7.widget.RecyclerView
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import com.aluf.kotlin.kotlinfirst.R
import com.aluf.kotlin.kotlinfirst.model.League
import org.jetbrains.anko.*
import org.jetbrains.anko.sdk27.coroutines.onClick


class ListLeagueAdapter(private val leagues: List<League>, private val listener: (League) -> Unit) :
    RecyclerView.Adapter<HolderLeague>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HolderLeague {
        return HolderLeague(
            LeagueUI().createView(
                AnkoContext.create(parent.context, parent)
            )
        )
    }

    override fun onBindViewHolder(holder: HolderLeague, position: Int) {
//        holder.bindItem(leagues[position], listener)
        holder.bindItem(leagues[position], listener)
    }

    override fun getItemCount(): Int = leagues.size
}



class HolderLeague (view: View) : RecyclerView.ViewHolder(view){
    private val leagueName: TextView = view.find(R.id.spn_league)
    fun bindItem(league: League, listener: (League) -> Unit) {
        leagueName.text = league.strLeague
        itemView.onClick {
            listener(league)
        }
    }

}

class LeagueUI : AnkoComponent<ViewGroup> {
    override fun createView(ui: AnkoContext<ViewGroup>): View {
        return with(ui) {
            linearLayout {
                lparams(width = matchParent, height = wrapContent)
                padding = dip(16)
                orientation = LinearLayout.HORIZONTAL

                textView {
                    id = R.id.spn_league
                    textSize = 16f
                }.lparams{
                    margin = dip(15)
                }
            }
        }
    }
}

