package com.aluf.kotlin.kotlinfirst.model.event

import com.aluf.kotlin.kotlinfirst.model.event.Event
import com.google.gson.annotations.SerializedName

data class FootballMatch (
    @SerializedName("events") var events: List<Event>)

