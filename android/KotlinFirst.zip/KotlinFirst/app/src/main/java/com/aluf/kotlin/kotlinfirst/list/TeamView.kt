package com.aluf.kotlin.kotlinfirst.list

import com.aluf.kotlin.kotlinfirst.model.Team

interface TeamView {
    fun showLoading()
    fun hideLoading()
    fun showTeamList(data: List<Team>)
}
