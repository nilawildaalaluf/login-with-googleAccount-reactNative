package com.aluf.kotlin.kotlinfirst.config

import retrofit2.Retrofit
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory
import retrofit2.converter.gson.GsonConverterFactory
import java.net.URL

class ApiRespository {

    fun doRequest(url: String): String {
        return URL(url).readText()
    }

//    companion object {
//        fun getClient() : Retrofit {
//            return Retrofit.Builder()
//                .baseUrl("https://www.thesportsdb.com/api/v1/json/1/")
//                .addConverterFactory(GsonConverterFactory.create())
//                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
//                .build()
//        }
//    }
}