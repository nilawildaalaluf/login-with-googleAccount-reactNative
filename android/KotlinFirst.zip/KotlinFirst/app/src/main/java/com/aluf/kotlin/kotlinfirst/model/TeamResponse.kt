package com.aluf.kotlin.kotlinfirst.model


data class TeamResponse(val teams: List<Team>)