package com.aluf.kotlin.kotlinfirst.config.repository
import android.content.Context
import com.aluf.kotlin.kotlinfirst.db.database
import com.aluf.kotlin.kotlinfirst.model.favorite.FavoriteScedule
import org.jetbrains.anko.db.classParser
import org.jetbrains.anko.db.insert
import org.jetbrains.anko.db.select
import org.jetbrains.anko.db.delete

class LocalRepositoryApi(private val context: Context) : LocalRepository {
    override fun checkFavorite(eventId: String): List<FavoriteScedule> {
        return context.database.use {
            val result = select(FavoriteScedule.TABLE_NAME)
                .whereArgs("(EVENT_ID = {id})",
                    "id" to eventId)
            val favorite = result.parseList(classParser<FavoriteScedule>())
            favorite
        }
    }


    override fun deleteData(eventId: String) {
        context.database.use{
           delete(
                FavoriteScedule.TABLE_NAME, "(EVENT_ID = {id})",
                "id" to eventId
            )
        }
    }

    override fun insertData(
        eventId: String,
        homeId: String,
        awayId: String,
        homeScore: String?,
        awayScore: String?,
        homeName: String,
        awayName: String,
        dateSchedule: String,
        timeScedule: String?
    ) {
        context.database.use {
            insert(
                FavoriteScedule.TABLE_NAME,
                FavoriteScedule.EVENT_ID to eventId,
                FavoriteScedule.HOME_TEAM_ID to homeId,
                FavoriteScedule.AWAY_TEAM_ID to awayId,
                FavoriteScedule.HOME_TEAM_NAME to homeName,
                FavoriteScedule.AWAY_TEAM_NAME to awayName,
                FavoriteScedule.HOME_TEAM_SCORE to homeScore,
                FavoriteScedule.AWAY_TEAM_SCORE to awayScore,
                FavoriteScedule.DATE_SCHEDULE to dateSchedule,
                FavoriteScedule.TIME_SCHEDULE to timeScedule
            )

        }
    }

    override fun getMatchFromDb(): List<FavoriteScedule> {
        lateinit var favoriteList :List<FavoriteScedule>
        context.database.use {
            val result = select(FavoriteScedule.TABLE_NAME)
            val favorite = result.parseList(classParser<FavoriteScedule>())
            favoriteList = favorite
        }
        return favoriteList
    }
}


