package com.aluf.kotlin.kotlinfirst.list

import com.aluf.kotlin.kotlinfirst.config.ApiRespository
import com.aluf.kotlin.kotlinfirst.config.TheSportDBApi
import com.aluf.kotlin.kotlinfirst.detail.CoroutineContextProvider
import com.aluf.kotlin.kotlinfirst.model.TeamResponse
import com.google.gson.Gson
import kotlinx.coroutines.experimental.android.UI
import kotlinx.coroutines.experimental.async
import org.jetbrains.anko.coroutines.experimental.bg

class TeamPresenter(private val view: TeamView,
                    private val apiRepository: ApiRespository,
                    private val gson: Gson,
                    private val context: CoroutineContextProvider = CoroutineContextProvider()) {
    fun getTeamList(league: String?) {
        view.showLoading()

        async(context.main) {
            //Proses request di background
            val data = bg {
                gson.fromJson(apiRepository.doRequest(TheSportDBApi.getTeams(league)), TeamResponse::class.java)
            }

            view.showTeamList(data.await().teams)
            view.hideLoading()
        }
    }
}
