package com.aluf.kotlin.kotlinfirst.list.schedule

import com.aluf.kotlin.kotlinfirst.model.event.Event
import com.aluf.kotlin.kotlinfirst.model.favorite.FavoriteScedule

interface SceduleView {
    fun showLoading()
    fun hideLoading()
    fun showEventLast(data: List<Event>)
    fun showNextMatch(data: List<Event>)
    fun showFavoriteMatch(data: List<FavoriteScedule>)
}
