package com.aluf.kotlin.kotlinfirst.detail.scedule

import android.content.Context
import android.os.Bundle
import android.support.v4.content.ContextCompat
import android.support.v4.widget.SwipeRefreshLayout
import android.support.v7.app.AppCompatActivity
import android.view.Menu
import android.view.MenuItem
import com.aluf.kotlin.kotlinfirst.R
import com.aluf.kotlin.kotlinfirst.config.ApiRespository
import com.aluf.kotlin.kotlinfirst.config.repository.LocalRepositoryApi
import com.aluf.kotlin.kotlinfirst.db.SQLiteHelper
import com.aluf.kotlin.kotlinfirst.model.Team
import com.aluf.kotlin.kotlinfirst.model.event.Event
import com.aluf.kotlin.kotlinfirst.model.favorite.FavoriteScedule
import com.google.gson.Gson
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.activity_detail_scedule.*
import org.jetbrains.anko.design.snackbar
import org.jetbrains.anko.support.v4.onRefresh
import org.jetbrains.anko.toast

class SceduleDetail : AppCompatActivity(), SceduleDetailView.View {


    private lateinit var presenter: SceduleDetailPresenter
    private lateinit var event: Event

    lateinit var favorite: FavoriteScedule
    private lateinit var id: String
    private var menuItem: Menu? = null
    private var isFavorite: Boolean = false
    private var isEvent : Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_scedule)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        var request = ApiRespository()
        val gson = Gson()
        val localRepo = LocalRepositoryApi(applicationContext)

        isEvent = intent.hasExtra("event")
        presenter = SceduleDetailPresenter(this, request, gson, localRepo)



        if(isEvent){
            event = intent.getParcelableExtra<Event>("event")
            presenter.showDataTeam(event)
            presenter.checkMatch(event.idEvent)

        }else{
            favorite = intent.getParcelableExtra<FavoriteScedule>("favorite")
            presenter.showDataFavoriteTeam(favorite)
            presenter.checkMatch(favorite.idEvent)


        }

    }

    override fun showDataTeam(event: Event?) {
        if(event != null) {
            supportActionBar?.title = event.strEvent
            dateScheduleTv.text = event.dateEvent.toString()
            homeNameTv.text = event.strHomeTeam
            homeScoreTv.text = event.intHomeScore
            awayNameTv.text = event.strAwayTeam
            awayScoreTv.text = event.intAwayScore

            homeScorerTv.text = event.strHomeGoalDetails
            awayScorerTv.text = event.strAwayGoalDetails

            gkHomeTv.text = event.strHomeLineupGoalkeeper
            gkAwayTv.text = event.strAwayLineupGoalkeeper

            defHomeTv.text = event.strHomeLineupDefense
            defAwayTv.text = event.strAwayLineupDefense

            midHomeTv.text = event.strHomeLineupMidfield
            midAwayTv.text = event.strAwayLineupMidfield

            forHomeTv.text = event.strHomeLineupForward
            forAwayTv.text = event.strAwayLineupForward

            subHomeTv.text = event.strHomeLineupSubstitutes
            subAwayTv.text = event.strAwayLineupSubstitutes

            shHomeTv.text = event.intHomeShots
            shAwayTv.text = event.intAwayShots

            presenter.getTeamsBadgeAway(event.idAwayTeam)
            presenter.getTeamsBadgeHome(event.idHomeTeam)
        }

    }

    override fun displayTeamBadgeHome(team: Team) {
        Picasso.get().load(team.teamBadge).into(homeImg)
    }

    override fun displayTeamBadgeAway(team: Team) {
        Picasso.get().load(team.teamBadge).into(awayImg)
    }
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.add_favorite, menu)
        menuItem = menu
        setFavorite()
        return true
    }


    private fun setFavorite() {
        if (isFavorite) {
            menuItem?.getItem(0)?.icon = ContextCompat.getDrawable(this, R.drawable.ic_added_to_favorites)
        }
        else{
            menuItem?.getItem(0)?.icon = ContextCompat.getDrawable(this, R.drawable.ic_add_to_favorites)
        }
    }

    override fun setFavoriteState(favList: List<FavoriteScedule>) {
        if(!favList.isEmpty()) isFavorite = true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                finish()
                true
            }
            R.id.add_to_favorite->{
                if (!isFavorite){
                    if(isEvent) {
                        presenter.insertMatch(
                            event.idEvent, event.idHomeTeam, event.idAwayTeam, event.intHomeScore, event.intAwayScore, event.strHomeTeam, event.strAwayTeam, event.dateEvent, event.strTime)
                    }
                    else {
                        presenter.insertMatch(
                            favorite.idEvent, favorite.idHomeTeam, favorite.idAwayTeam, favorite.scrHomeTeam, favorite.scrAwayTeam, favorite.idHomeTeamName, favorite.idAwayTeamName, favorite.dateSchedule, favorite.timeScedule)
                    }
                    toast("Event added to favorite")
                    isFavorite = !isFavorite
                }else{
                    if(isEvent) {
                        presenter.deleteMatch(event.idEvent)

                    }
                    else{
                        presenter.deleteMatch(favorite.idEvent)
                    }
                    toast("Event removed favorite")
                    isFavorite = !isFavorite
                }
                setFavorite()
                true
            }
            else -> {
                super.onOptionsItemSelected(item)
            }
        }
    }




}