package com.aluf.kotlin.kotlinfirst.list.schedule

import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import com.aluf.kotlin.kotlinfirst.R
import com.aluf.kotlin.kotlinfirst.model.event.Event
import com.aluf.kotlin.kotlinfirst.OnItemClickListener
import com.aluf.kotlin.kotlinfirst.utils.DateFormatter

class SceduleAdapter (val events: MutableList<Event>, val onItemClickListener: OnItemClickListener<Event>? = null) : RecyclerView.Adapter<ListEventHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int)=

        ListEventHolder(LayoutInflater.from(parent.context).inflate(R.layout.list_scedule, parent, false))

    override fun getItemCount(): Int {
        return events.size
    }

    override fun onBindViewHolder(holder: ListEventHolder, position: Int) {
        holder.bindItem(events[position])
        holder.itemView.setOnClickListener { it ->
            onItemClickListener?.onClicked(events.get(position))
        }

    }
}

class ListEventHolder(view: View) : RecyclerView.ViewHolder(view) {
    private val dateSoccer = view.findViewById<TextView>(R.id.date_soccer)
    private val nameHomeSoccer = view.findViewById<TextView>(R.id.home_soccer)
    private val scoreHomeSoccer = view.findViewById<TextView>(R.id.score_home_soccer)
    private val nameAwaySoccer = view.findViewById<TextView>(R.id.away_soccer)
    private val scoreAwaySoccer = view.findViewById<TextView>(R.id.score_away_soccer)
    private val timeSoccer = view.findViewById<TextView>(R.id.time_soccer)

    fun bindItem(events: Event) {
        nameHomeSoccer.text = events.strHomeTeam
        nameAwaySoccer.text = events.strAwayTeam
        scoreHomeSoccer.text = events.intHomeScore
        scoreAwaySoccer.text = events.intAwayScore
//        timeSoccer.text = events.strTime?.split()

        try {
            val eventDate = DateFormatter.formatToDate(events.strDate + " " + events.strTime?.split("+")?.get(0), "dd/MM/yy HH:mm:ss")
            dateSoccer.text = DateFormatter.formatToString(eventDate, "EEEE, dd MMMM yyyy")
            timeSoccer.text = DateFormatter.formatToString(eventDate, "HH:ss")
        } catch (e: Exception) {
        }

    }



}