package com.aluf.kotlin.kotlinfirst.detail.scedule

import com.aluf.kotlin.kotlinfirst.model.Team
import com.aluf.kotlin.kotlinfirst.model.event.Event
import com.aluf.kotlin.kotlinfirst.model.favorite.FavoriteScedule

interface SceduleDetailView{
    interface View{
    fun showDataTeam(event: Event?)
    fun displayTeamBadgeHome(team: Team)
    fun displayTeamBadgeAway(team: Team)
        fun setFavoriteState(favList: List<FavoriteScedule>)
    }
}