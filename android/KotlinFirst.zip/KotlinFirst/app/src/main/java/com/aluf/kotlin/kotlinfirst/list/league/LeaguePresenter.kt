package com.aluf.kotlin.kotlinfirst.list.league

import com.aluf.kotlin.kotlinfirst.config.ApiRespository
import com.aluf.kotlin.kotlinfirst.config.TheSportDBApi
import com.aluf.kotlin.kotlinfirst.detail.CoroutineContextProvider
import com.aluf.kotlin.kotlinfirst.model.LeaguesResponse
import com.google.gson.Gson
import kotlinx.coroutines.experimental.async
import org.jetbrains.anko.coroutines.experimental.bg

class LeaguePresenter (private val view: LeagueView, private val apiRepository: ApiRespository, private val gson: Gson,
                       private val context: CoroutineContextProvider = CoroutineContextProvider()
) {
    fun getAllEvent() {
        view.showLoading()

        async(context.main) {
            //Proses request di background
            val data = bg {
                gson.fromJson(apiRepository.doRequest(TheSportDBApi.getAllEvent()), LeaguesResponse::class.java)
            }

            view.showListLeague(data.await().leagues)
            view.hideLoading()
        }
    }
}