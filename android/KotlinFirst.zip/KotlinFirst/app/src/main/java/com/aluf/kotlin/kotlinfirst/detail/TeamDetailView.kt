package com.aluf.kotlin.kotlinfirst.detail

import com.aluf.kotlin.kotlinfirst.model.Team

interface TeamDetailView {
    fun showLoading()
    fun hideLoading()
    fun showTeamDetail(data: List<Team>)
}
