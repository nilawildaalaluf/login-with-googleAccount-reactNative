package com.aluf.kotlin.kotlinfirst.model

import com.aluf.kotlin.kotlinfirst.model.event.Event
import com.google.gson.annotations.SerializedName

class SearchedMatches {
    @SerializedName("event")
    lateinit var events: List<Event>
}