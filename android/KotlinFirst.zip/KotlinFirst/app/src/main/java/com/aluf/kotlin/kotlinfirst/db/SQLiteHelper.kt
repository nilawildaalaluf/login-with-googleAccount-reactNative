package com.aluf.kotlin.kotlinfirst.db

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import com.aluf.kotlin.kotlinfirst.model.favorite.Favorite
import com.aluf.kotlin.kotlinfirst.model.favorite.FavoriteScedule
import org.jetbrains.anko.db.*

class SQLiteHelper(context: Context) : ManagedSQLiteOpenHelper(context, "FavoriteTeam.db",
null, 1) {
    companion object {
        private var instance: SQLiteHelper? = null

        @Synchronized
        fun getInstance(context: Context): SQLiteHelper {
            if (instance == null) {
                instance = SQLiteHelper(context.applicationContext)
            }
            return instance!!
        }
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.createTable(
            Favorite.TABLE_NAME, true,
            Favorite.ID to INTEGER + PRIMARY_KEY + AUTOINCREMENT,
            Favorite.TEAM_ID to TEXT + UNIQUE,
            Favorite.TEAM_NAME to TEXT,
            Favorite.TEAM_BADGE to TEXT
        )
        db.createTable(
            FavoriteScedule.TABLE_NAME, true,
            FavoriteScedule.ID to INTEGER + PRIMARY_KEY + AUTOINCREMENT,
            FavoriteScedule.EVENT_ID to TEXT + UNIQUE,
            FavoriteScedule.HOME_TEAM_ID to TEXT,
            FavoriteScedule.AWAY_TEAM_ID to TEXT,
            FavoriteScedule.HOME_TEAM_NAME to TEXT,
            FavoriteScedule.AWAY_TEAM_NAME to TEXT,
            FavoriteScedule.HOME_TEAM_SCORE to TEXT,
            FavoriteScedule.AWAY_TEAM_SCORE to TEXT,
            FavoriteScedule.DATE_SCHEDULE to TEXT,
            FavoriteScedule.TIME_SCHEDULE to TEXT
        )

    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.dropTable(Favorite.TABLE_NAME, true)
        db.dropTable(FavoriteScedule.TABLE_NAME, true)
    }
}

val Context.database: SQLiteHelper
    get() = SQLiteHelper.getInstance(applicationContext)