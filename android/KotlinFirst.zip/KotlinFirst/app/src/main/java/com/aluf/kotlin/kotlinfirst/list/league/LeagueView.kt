package com.aluf.kotlin.kotlinfirst.list.league


import com.aluf.kotlin.kotlinfirst.model.League

interface LeagueView {
    fun showLoading()
    fun hideLoading()
    fun showListLeague(data: List<League>)
}
