package com.aluf.kotlin.kotlinfirst.model

import com.google.gson.annotations.SerializedName


data class League(
    @SerializedName("idLeague")
    val idLeague: String?,
    @SerializedName("strLeague")
    val strLeague: String?,
    val name: Any
)