package com.aluf.kotlin.kotlinfirst.detail

import com.aluf.kotlin.kotlinfirst.config.ApiRespository
import com.aluf.kotlin.kotlinfirst.config.TheSportDBApi
import com.aluf.kotlin.kotlinfirst.model.TeamResponse
import com.google.gson.Gson
import kotlinx.coroutines.experimental.android.UI
import kotlinx.coroutines.experimental.async
import org.jetbrains.anko.coroutines.experimental.bg

class TeamDetailPresenter(private val view: TeamDetailView,
                          private val apiRepository: ApiRespository,
                          private val gson: Gson,
                          private val context: CoroutineContextProvider = CoroutineContextProvider()) {
    fun getTeamDetail(teamId: String) {
        view.showLoading()
        async(context.main) {
            val data = bg{gson.fromJson(apiRepository.doRequest(TheSportDBApi.getTeamDetail(teamId)), TeamResponse::class.java)}

                view.hideLoading()
                view.showTeamDetail(data.await().teams)

        }
    }
}

