package com.aluf.kotlin.kotlinfirst.list.schedule

import android.annotation.SuppressLint
import android.content.Context
import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v4.widget.SwipeRefreshLayout
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import com.aluf.kotlin.kotlinfirst.OnItemClickListener
import com.aluf.kotlin.kotlinfirst.R
import com.aluf.kotlin.kotlinfirst.R.color.colorAccent
import com.aluf.kotlin.kotlinfirst.config.ApiRespository
import com.aluf.kotlin.kotlinfirst.config.repository.LocalRepositoryApi
import com.aluf.kotlin.kotlinfirst.detail.scedule.SceduleDetail
import com.aluf.kotlin.kotlinfirst.favorite.FavoriteSceduleAdapter
import com.aluf.kotlin.kotlinfirst.model.event.Event
import com.aluf.kotlin.kotlinfirst.model.favorite.FavoriteScedule
import com.google.gson.Gson
import org.jetbrains.anko.*
import org.jetbrains.anko.design.bottomNavigationView
import org.jetbrains.anko.recyclerview.v7.recyclerView
import org.jetbrains.anko.support.v4.ctx
import org.jetbrains.anko.support.v4.intentFor
import org.jetbrains.anko.support.v4.onRefresh
import org.jetbrains.anko.support.v4.swipeRefreshLayout

 class ScheduleFragment: Fragment(), SceduleView {

     private lateinit var listMatch: RecyclerView
    private lateinit var progressBar: ProgressBar
    private lateinit var swipeRefresh: SwipeRefreshLayout

    private var events: MutableList<Event> = mutableListOf()
    private var favorites: MutableList<FavoriteScedule> = mutableListOf()
    private lateinit var presenter: ScedulePresenter
    private lateinit var adapter: SceduleAdapter
    private lateinit var favoriteAdapter: FavoriteSceduleAdapter


    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)


        adapter = SceduleAdapter(events, OnItemClickListener {
            Toast.makeText(context, "click", Toast.LENGTH_LONG).show()
            startActivity(intentFor<SceduleDetail>("event" to it))
        })
        favoriteAdapter = FavoriteSceduleAdapter(favorites){
            startActivity(intentFor<SceduleDetail>("favorite" to it))
        }


        val request = ApiRespository()
        val gson = Gson()
        var repository = LocalRepositoryApi(activity!!.applicationContext)

        presenter = ScedulePresenter(this, request, gson, repository)

        presenter.getEventLast(leagueId = "4329")

        swipeRefresh.onRefresh {
            presenter.getEventLast(leagueId = "4329")
        }

    }


    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return createView(AnkoContext.create(ctx))

    }

    @SuppressLint("ResourceType")
    fun createView(ui: AnkoContext<Context>): View = with(ui) {

        linearLayout {
            lparams(width = matchParent, height = wrapContent)
            orientation = LinearLayout.VERTICAL
            linearLayout {
                lparams(width = matchParent, height = wrapContent)
                bottomNavigationView {
                    inflateMenu(R.menu.bottom_navigation)
                    fitsSystemWindows = true
                    backgroundResource = R.color.white
                    itemBackgroundResource = R.color.white
                    selectedItemId = R.id.last_match
                    itemIconTintList = resources.getColorStateList(R.color.colorPrimary)
                    itemTextColor = resources.getColorStateList(R.color.colorPrimary)
                    lparams(width = matchParent, height = wrapContent)
                    {
                        backgroundColor = R.color.white
                        backgroundColorResource = R.color.white

                    }
                }.setOnNavigationItemSelectedListener { item ->
                    when (item.itemId) {
                        R.id.last_match -> {
                            presenter.getEventLast(leagueId = "4328")
                        }
                        R.id.upcoming_match -> {
                            presenter.getNextMatch(leagueId = "4328")
                        }
                        R.id.favorites -> {
                            presenter.getFavoriteMatch()
                        }
                    }

                    false
                }
            }

            linearLayout {
                lparams(width = matchParent, height = wrapContent)
                orientation = LinearLayout.VERTICAL
                topPadding = dip(16)
                leftPadding = dip(16)
                rightPadding = dip(16)

                swipeRefresh = swipeRefreshLayout {
                    setColorSchemeResources(
                        android.R.color.holo_green_light, colorAccent,
                        android.R.color.holo_orange_light,
                        android.R.color.holo_red_light
                    )

                    relativeLayout {
                        lparams(width = matchParent, height = wrapContent)
                        listMatch = recyclerView {
                            //                        id = R.id.list
                            lparams(width = matchParent, height = wrapContent)
                            layoutManager = LinearLayoutManager(ctx)
                        }

                        progressBar = progressBar {

                        }.lparams {
                            centerHorizontally()
                        }
                    }
                }
            }
        }
    }

    override fun showLoading() {
        progressBar.visible()
    }

    override fun hideLoading() {
        progressBar.invisible()
    }

    override fun showEventLast(data: List<Event>) {
        swipeRefresh.isRefreshing = false
        events.clear()
        events.addAll(data)
        favorites.clear()
        listMatch.adapter = adapter
        adapter.notifyDataSetChanged()
    }
    override fun showNextMatch(data: List<Event>) {
        swipeRefresh.isRefreshing = false
        events.clear()
        favorites.clear()
        events.addAll(data)
        listMatch.adapter = adapter
        adapter.notifyDataSetChanged()
    }

     override fun showFavoriteMatch(data: List<FavoriteScedule>) {
         swipeRefresh.isRefreshing = false
         events.clear()
         favorites.clear()
         favorites.addAll(data)
         listMatch.adapter = favoriteAdapter
         adapter.notifyDataSetChanged()
     }


    fun View.visible() {
        visibility = View.VISIBLE
    }

    fun View.invisible() {
        visibility = View.INVISIBLE
    }


}

