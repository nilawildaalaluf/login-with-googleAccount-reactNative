package com.aluf.kotlin.kotlinfirst;

public interface OnItemClickListener<M> {

    void onClicked(M m);
}
