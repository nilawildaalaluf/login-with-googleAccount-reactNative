package com.aluf.kotlin.kotlinfirst.config.repository

import com.aluf.kotlin.kotlinfirst.model.favorite.FavoriteScedule

interface LocalRepository {


    fun getMatchFromDb() : List<FavoriteScedule>

    fun insertData(eventId: String, homeId: String, awayId: String, homeScore: String?, awayScore : String?, homeName: String, awayName: String, dateSchedule: String, timeScedule:String?)

    fun deleteData(eventId: String)

    fun checkFavorite(eventId: String) : List<FavoriteScedule>
}
